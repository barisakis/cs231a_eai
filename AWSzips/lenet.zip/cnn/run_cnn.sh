./../../caffe/build/tools/caffe train \
	--solver=solver.prototxt
