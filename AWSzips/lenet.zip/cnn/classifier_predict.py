import caffe
import numpy as np
import os
import time

DEPLOY_PATH = 'deploy.prototxt'
MODEL_PATH = '../snapshots/lenet_iter_5000.caffemodel'
IMAGE_PATH = '../data/test_img.jpg'
IMAGE_DIR = '../data/splits/'
MEAN_IMAGE_PATH = '../data/mean_image.binaryproto'
SET = 'test'

caffe.set_device(0)
caffe.set_mode_gpu()

blob = caffe.proto.caffe_pb2.BlobProto()
data = open(MEAN_IMAGE_PATH, 'rb').read()
blob.ParseFromString(data)
mean_img = np.array(caffe.io.blobproto_to_array(blob))[0]

net = caffe.Classifier(DEPLOY_PATH,
		       MODEL_PATH,
 		       mean=mean_img,
		       raw_scale=255,
		       image_dims=(250, 250))

#img = caffe.io.load_image(IMAGE_PATH, color=False)
#pred = net.predict([img])
#print pred[0]
#print pred[0].argmax()


labels = open(IMAGE_DIR + SET + '/labels.txt', 'r')
counts = [0.0, 0.0] #[Total, Correct]
for line in labels:
	start = time.time()
	data = line.strip().split(' ')
        filename = data[0]
        true_label = data[1]
        image_path = IMAGE_DIR + SET + '/images/' + filename
	img = caffe.io.load_image(image_path, color=False)
	pred = net.predict([img])
	print len(pred[0])
	pred_label = str(pred[0].argmax())
	elapsed = time.time() - start
	print (elapsed, true_label, pred_label)
	if pred_label == true_label:
		counts[1] += 1
	counts[0] += 1
print counts[1] / counts[0]
