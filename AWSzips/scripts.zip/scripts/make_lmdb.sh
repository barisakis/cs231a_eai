
TOOLS=~/caffe/build/tools
DATA_PATH=~/project/data/splits
OUTPUT_PATH=~/project/data/lmdb


echo "Creating train lmdb..."
GLOG_logtostderr=1 \
	$TOOLS/convert_imageset \
	--gray \
	--shuffle \
	$DATA_PATH/train/images/ \
	$DATA_PATH/train/labels.txt \
	$OUTPUT_PATH/train_lmdb

echo "Create val lmdb..."
GLOG_logtostderr=1 \
        $TOOLS/convert_imageset \
        --gray \
	--shuffle \
        $DATA_PATH/val/images/ \
        $DATA_PATH/val/labels.txt \
        $OUTPUT_PATH/val_lmdb

echo "Create test lmdb..."
GLOG_logtostderr=1 \
        $TOOLS/convert_imageset \
        --gray \
	--shuffle \
        $DATA_PATH/test/images/ \
        $DATA_PATH/test/labels.txt \
        $OUTPUT_PATH/test_lmdb
