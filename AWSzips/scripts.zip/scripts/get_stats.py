import sys
import caffe
import numpy as np
import sklearn.metrics as skm

DEPLOY_PATH = '../alexnet/deploy.prototxt'
MODEL_PATH = '../snapshots/alexnet_iter_5000.caffemodel'
MEAN_IMAGE_PATH = '../data/mean_image.binaryproto'
IMAGE_DIR = '../data/splits/'
SET = 'val'

emotion_dict = {0:'neutral',
		1:'anger',
		2:'contempt',
		3:'disgust',
		4:'fear',
		5:'happy',
		6:'sad',
		7:'surprise'}

def loadCNN():
	caffe.set_device(0)
	caffe.set_mode_gpu()

	blob = caffe.proto.caffe_pb2.BlobProto()
	data = open(MEAN_IMAGE_PATH, 'rb').read()
	blob.ParseFromString(data)
	mean_img = np.array(caffe.io.blobproto_to_array(blob))[0]

	net = caffe.Classifier(DEPLOY_PATH,
        	               MODEL_PATH,
                	       mean=mean_img,
                      	       raw_scale=255,
                	       image_dims=(250, 250))
	return net
	
def getPredictions(net, dataset):
	gold_labels = []
	pred_labels = []
	
	label_file = open(IMAGE_DIR + dataset + '/labels.txt', 'r')
	lines = label_file.readlines()
	for i, line in enumerate(lines):
		(image_filename, label) = line.strip().split(' ')
		image_path = IMAGE_DIR + dataset + '/images/' + image_filename
	        img = caffe.io.load_image(image_path, color=False)
	        pred = net.predict([img])
        	pred_label = pred[0].argmax()
		pred_labels.append(pred_label)
		gold_labels.append(int(label))
		if ((i+1) % 100) == 0:
			print "Processed " + str(i+1) + " of " + str(len(lines))

	return (gold_labels, pred_labels)

def getConfusionMatrix(labels, preds):
	cm = skm.confusion_matrix(labels, preds)
	#cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
	return cm

def getPrecision(labels, preds):
	prec = skm.precision_score(labels, preds, average=None)
	return prec

def getRecall(labels, preds):
	recall = skm.recall_score(labels, preds, average=None)
	return recall

def getAccuracy(labels, preds):
	count = 0.0
	for i in range(len(labels)):
		if labels[i] == preds[i]:
			count += 1
	return count / len(labels)	

def main():
	net = loadCNN()
	(gold, pred) = getPredictions(net, SET)
	print getConfusionMatrix(gold, pred)
	print getPrecision(gold, pred)
	print getRecall(gold, pred)
	print getAccuracy(gold, pred)

if __name__ == "__main__":
	main()
