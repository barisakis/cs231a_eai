./~/caffe/build/tools/caffe train \
	--solver=~/project/cnn/solver.prototxt
