import socket

UDP_IP = socket.gethostbyaddr("54.153.80.45")[0]
UDP_PORT = 60001

sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock.bind((UDP_IP, UDP_PORT))

print "UDP Host IP:", UDP_IP
print "UDP Host port:", UDP_PORT

while True:
    data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
    print "received message:", data