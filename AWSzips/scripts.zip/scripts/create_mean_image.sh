TOOLS=~/caffe/build/tools
DATA_PATH=~/project/data/lmdb
OUTPUT_PATH=~/project/data

$TOOLS/compute_image_mean \
	$DATA_PATH/train_lmdb \
	$OUTPUT_PATH/mean_image.binaryproto
